import java.util.Scanner;

public class HelloWorld {
    public  static void main(String args[]){
        Scanner myObj = new Scanner(System.in);
        int nextInt = myObj.nextInt();
        myObj.nextLine();
        for (int i=0; i<nextInt; i++){
            String nextLine = myObj.nextLine();
            System.out.println("Hello, "+ nextLine + "!");
        }
    }
}